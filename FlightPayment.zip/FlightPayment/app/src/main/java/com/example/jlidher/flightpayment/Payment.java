package com.example.jlidher.flightpayment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.IOException;



public class Payment extends AppCompatActivity  {



    private EditText nameOnCard;
    private EditText cardNum;
    private EditText ccv;
    private EditText billingAddress;
    private EditText postalCode;
    private Spinner expYearSpinner;
    private Spinner expMonthSpinner;
    private Spinner countrySpinner;
    private EditText email;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        nameOnCard = findViewById(R.id.cardholder);
        cardNum = findViewById(R.id.cardNumber);
        ccv = findViewById(R.id.cvv);
        billingAddress = findViewById(R.id.billingAddy);
        postalCode = findViewById(R.id.postalCode);
        email = findViewById(R.id.email);

        expMonthSpinner = findViewById(R.id.expMonth);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.expMonth, android.R.layout.simple_spinner_dropdown_item);
        expMonthSpinner.setAdapter(adapter);

        expYearSpinner = findViewById(R.id.expYear);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.expYear, android.R.layout.simple_spinner_dropdown_item);
        expYearSpinner.setAdapter(adapter2);

        countrySpinner = findViewById(R.id.countrySpin);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.Country, android.R.layout.simple_spinner_dropdown_item);
        countrySpinner.setAdapter(adapter3);




    }

    public void confirm2(View view) throws IOException {

        String nameOnCardString = nameOnCard.getText().toString();
        String cardNumString = cardNum.getText().toString();
        String ccvString = ccv.getText().toString();
        String billingAddressString = billingAddress.getText().toString();
        String postalCodeString = postalCode.getText().toString();
        String expMonthString = expMonthSpinner.getSelectedItem().toString();
        String expYearString = expYearSpinner.getSelectedItem().toString();
        String countryString = countrySpinner.getSelectedItem().toString();
        String emailString = email.getText().toString();
        String countryPos = "";
        String expDate;

        boolean validName = false;
        boolean validCardNum = false;
        boolean validCCV = false;
        boolean validBillingAddress = false;
        boolean validPostalCode = false;
        boolean validexpDate = false;
        boolean validCounty = false;
        boolean validEmail = false;


        if(!nameOnCardString.equals("")){
            validName = true;
        }else{
            Toast.makeText(getApplicationContext(), "No card holder name! Please provide.", Toast.LENGTH_LONG).show();
        }

        if(!cardNumString.equals("") && cardNumString.length() == 16){
            validCardNum = true;
        }else{
            Toast.makeText(getApplicationContext(), "Invalid card number!", Toast.LENGTH_LONG).show();
        }

        if(!ccvString.equals("") && ccvString.length() == 3){
            validCCV = true;
        }else{
            Toast.makeText(getApplicationContext(), "Invalid CCV! Should be 3 digits long (found on back of card)", Toast.LENGTH_LONG).show();
        }

        if(!billingAddressString.equals("")){
            validBillingAddress = true;
        }else{
            Toast.makeText(getApplicationContext(), "Invalid billing address!", Toast.LENGTH_LONG).show();
        }

        if(countryString.equals("USA")){
            if(postalCodeString.length() == 5 || postalCodeString.length() == 6){
                validPostalCode = true;
            }else{
                Toast.makeText(getApplicationContext(), "Invalid ZIP Code ", Toast.LENGTH_LONG).show();
            }
        }else if(countryString.equals("Canada")){
            if(postalCodeString.length() == 6 || postalCodeString.length() == 7){
                validPostalCode = true;
            }else{
                Toast.makeText(getApplicationContext(), "Invalid Postal Code ", Toast.LENGTH_LONG).show();
            }
        }else{
            if(!postalCodeString.equals("")){
                validPostalCode = true;
            }
        }

        if(!countryString.equals("Country")){
            validCounty = true;
            countryPos = Integer.toString(countrySpinner.getSelectedItemPosition());
        }else{
            Toast.makeText(getApplicationContext(), "Please select your country.", Toast.LENGTH_LONG).show();
        }


        if(!expMonthString.equals("Month") && !expYearString.equals("Year")){
            validexpDate = true;
        }else{
            Toast.makeText(getApplicationContext(),"Invalid expiry date.",Toast.LENGTH_LONG).show();
        }

        if(!emailString.equals("") && emailString.contains("@") && (emailString.contains(".com") || emailString.contains(".ca"))){
            validEmail = true;
        }else{
            Toast.makeText(getApplicationContext(), "Invalid email", Toast.LENGTH_LONG).show();
        }


        if(validName && validCardNum && validCCV && validBillingAddress && validPostalCode && validCounty && validexpDate &&validEmail){
            Toast.makeText(getApplicationContext(), "Payment Proccessed. Reciept has been emailed.", Toast.LENGTH_LONG).show();
        }

    }
    }




